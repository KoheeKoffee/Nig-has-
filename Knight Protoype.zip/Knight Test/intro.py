import pygame
import cv2
import os
import numpy as np
import subprocess

pygame.init()
pygame.mixer.init()

WINDOW_SIZE = (1280, 720)
screen = pygame.display.set_mode(WINDOW_SIZE)
pygame.display.set_caption("Intro Video")

def play_intro():
    video_path = 'intro.mp4'
    if not os.path.exists(video_path):
        print("Error: intro.mp4 not found")
        return False

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("Error: Could not open video file")
        return False

    bgm = pygame.mixer.Sound("intro_bgm.mp3")
    bgm.set_volume(0.5)
    bgm.play()

    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    clock = pygame.time.Clock()

    running = True
    while running:
        ret, frame = cap.read()
        if not ret:
            running = False
            break

        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        frame_surface = pygame.surfarray.make_surface(np.transpose(frame, (1, 0, 2)))

        frame_surface = pygame.transform.scale(frame_surface, WINDOW_SIZE)

        screen.blit(frame_surface, (0, 0))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False

        clock.tick(fps)

    cap.release()
    bgm.stop()
    pygame.time.wait(500)
    return True

# Only run main_menu if intro completes successfully
if play_intro():
    pygame.quit()
    subprocess.run(['python', 'Main_menu.py'])
else:
    pygame.quit()
