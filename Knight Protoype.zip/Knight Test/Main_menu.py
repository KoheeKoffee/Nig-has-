import pygame
import sys
import os
import subprocess


pygame.init()
pygame.mixer.init()  


WINDOW_SIZE = (1280, 720)
screen = pygame.display.set_mode(WINDOW_SIZE)
pygame.display.set_caption("Blue Vs Red: ft. Dante from DMC")


background = pygame.image.load("main_menu_sample.png")
background = pygame.transform.scale(background, WINDOW_SIZE)
background_rect = background.get_rect(center=(WINDOW_SIZE[0]//2, WINDOW_SIZE[1]//2))


WHITE = (255, 255, 255)
BLACK = (0, 0, 0)


title_font = pygame.font.Font(None, 74)
menu_font = pygame.font.Font(None, 50)


BUTTON_WIDTH = 200
BUTTON_HEIGHT = 50
BUTTON_PADDING = 20

def draw_button(text, y_position):
    button_rect = pygame.Rect((WINDOW_SIZE[0] - BUTTON_WIDTH) // 2, 
                            y_position,
                            BUTTON_WIDTH, 
                            BUTTON_HEIGHT)
    

    pygame.draw.rect(screen, WHITE, button_rect)
    pygame.draw.rect(screen, BLACK, button_rect, 2)
    

    text_surface = menu_font.render(text, True, BLACK)
    text_rect = text_surface.get_rect(center=button_rect.center)
    screen.blit(text_surface, text_rect)
    
    return button_rect

def main_menu():

    menu_bgm = pygame.mixer.Sound("bgm_menu_sample.mp3")
    menu_bgm.set_volume(0.3)  
    menu_bgm.play(-1)  
    
    while True:
        screen.blit(background, background_rect)
        
        title_box = pygame.Rect(180, 100, 920, 150)

        pygame.draw.rect(screen, WHITE, title_box)
        pygame.draw.rect(screen, BLACK, title_box, 4)
        
        title1 = title_font.render("NIG HAS'S", True, BLACK)
        title2 = title_font.render("Blue Vs Red: ft. Vergil? from DMC", True, BLACK)
        title1_rect = title1.get_rect(center=(WINDOW_SIZE[0]//2, 150))
        title2_rect = title2.get_rect(center=(WINDOW_SIZE[0]//2, 200))
        screen.blit(title1, title1_rect)
        screen.blit(title2, title2_rect)

        start_button = draw_button("Start", 350)
        controls_button = draw_button("Controls", 430) 
        settings_button = draw_button("Settings", 510)
        quit_button = draw_button("Quit Game", 590)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                menu_bgm.stop() 
                pygame.quit()
                sys.exit()
                
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                
                if start_button.collidepoint(mouse_pos):
                    menu_bgm.stop() 
                    pygame.quit()
                    subprocess.run(['python', 'game_test.py'])
                    return
                elif controls_button.collidepoint(mouse_pos):
                    return "controls"
                elif settings_button.collidepoint(mouse_pos):
                    return "settings"
                elif quit_button.collidepoint(mouse_pos):
                    menu_bgm.stop() 
                    pygame.quit()
                    sys.exit()

        pygame.display.flip()

if __name__ == "__main__":
    main_menu()
