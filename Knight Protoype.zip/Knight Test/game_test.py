import pygame
import sys
import os

pygame.init()
pygame.mixer.init()  # Initialize the mixer module

WINDOW_SIZE = (1280, 720)  
screen = pygame.display.set_mode(WINDOW_SIZE)
pygame.display.set_caption("Two Players")

# Pause button constants
PAUSE_BUTTON_SIZE = 40
PAUSE_BUTTON_PADDING = 20
PAUSE_BUTTON_POS = (WINDOW_SIZE[0] - PAUSE_BUTTON_SIZE - PAUSE_BUTTON_PADDING, PAUSE_BUTTON_PADDING)

bgm = pygame.mixer.Sound("bgm_sample.mp3")
bgm.set_volume(0.2)  
bgm.play(-1)  

background = pygame.image.load("bg.png")
background = pygame.transform.scale(background, WINDOW_SIZE)
background_rect = background.get_rect(center=(WINDOW_SIZE[0]//2, WINDOW_SIZE[1]//2))

WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)

PLAYER_SIZE = 50
INITIAL_POS1 = [280, 300]
INITIAL_POS2 = [950, 300]
player1_pos = INITIAL_POS1.copy()
player2_pos = INITIAL_POS2.copy()
PLAYER_SPEED = 5
GRAVITY = 0.6
REDUCED_GRAVITY = 0.1  # Added reduced gravity for below main platform
JUMP_SPEED = -15
VOID_Y = 900  # Changed to match window height
VOID_DAMAGE = 20

player1_vel = [0, 0]
player2_vel = [0, 0]

player1_respawn_timer = 0
player2_respawn_timer = 0
RESPAWN_FLASH_DURATION = 60
FLASH_INTERVAL = 10

platforms = [
    pygame.Rect(160, 500, 960, 20),
    pygame.Rect(280, 350, 120, 20),
    pygame.Rect(580, 250, 120, 20),
    pygame.Rect(880, 350, 120, 20)
]

MAX_HEALTH = 100
player1_health = MAX_HEALTH
player2_health = MAX_HEALTH
HEALTH_BAR_WIDTH = 200
HEALTH_BAR_HEIGHT = 20
HEALTH_BAR_P1_POS = (WINDOW_SIZE[0]//2 - HEALTH_BAR_WIDTH - 350, 30)  # Changed position
HEALTH_BAR_P2_POS = (WINDOW_SIZE[0]//2 + 350, 30)  # Changed position

GAME_DURATION = 60

running = True
paused = False
game_over = False
clock = pygame.time.Clock()

font = pygame.font.Font(None, 36)
timer_font = pygame.font.Font(None, 48)
countdown_font = pygame.font.Font(None, 150)
pause_font = pygame.font.Font(None, 74)
victory_font = pygame.font.Font(None, 100)

# Button dimensions
BUTTON_WIDTH = 200
BUTTON_HEIGHT = 50
BUTTON_PADDING = 20

def draw_pause_button():
    pause_rect = pygame.Rect(PAUSE_BUTTON_POS[0], PAUSE_BUTTON_POS[1], PAUSE_BUTTON_SIZE, PAUSE_BUTTON_SIZE)
    pygame.draw.rect(screen, BLACK, pause_rect, 2)
    pygame.draw.rect(screen, (200, 200, 200), pause_rect)
    
    # Draw pause icon
    bar_width = 4
    bar_height = 20
    bar_padding = 8
    pygame.draw.rect(screen, BLACK, (PAUSE_BUTTON_POS[0] + bar_padding, 
                                   PAUSE_BUTTON_POS[1] + (PAUSE_BUTTON_SIZE - bar_height)//2,
                                   bar_width, bar_height))
    pygame.draw.rect(screen, BLACK, (PAUSE_BUTTON_POS[0] + PAUSE_BUTTON_SIZE - bar_padding - bar_width,
                                   PAUSE_BUTTON_POS[1] + (PAUSE_BUTTON_SIZE - bar_height)//2,
                                   bar_width, bar_height))
    return pause_rect

def draw_button(text, position, width=BUTTON_WIDTH, height=BUTTON_HEIGHT):
    button_rect = pygame.Rect(position[0], position[1], width, height)
    pygame.draw.rect(screen, BLACK, button_rect, 2)
    pygame.draw.rect(screen, (200, 200, 200), button_rect)
    
    text_surface = font.render(text, True, BLACK)
    text_rect = text_surface.get_rect(center=button_rect.center)
    screen.blit(text_surface, text_rect)
    return button_rect

def restart_game():
    global player1_pos, player2_pos, player1_vel, player2_vel
    global player1_health, player2_health, game_over
    global game_started, current_number, countdown_start
    global start_time, player1_respawn_timer, player2_respawn_timer
    
    # Reset positions and velocities
    player1_pos = INITIAL_POS1.copy()
    player2_pos = INITIAL_POS2.copy()
    player1_vel = [0, 0]
    player2_vel = [0, 0]
    
    # Reset health
    player1_health = MAX_HEALTH
    player2_health = MAX_HEALTH
    
    # Reset timers
    player1_respawn_timer = 0
    player2_respawn_timer = 0
    
    # Reset game state
    game_over = False
    game_started = False
    current_number = 0
    countdown_start = pygame.time.get_ticks()
    
    # Restart music
    bgm.stop()
    bgm.play(-1)

# Countdown sequence
countdown_numbers = ["3", "2", "1", "FIGHT!"]
countdown_duration = 1000  # 1 second per number
game_started = False
countdown_start = pygame.time.get_ticks()
current_number = 0

while running:
    current_time = pygame.time.get_ticks()
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            if game_started and not game_over:
                pause_rect = pygame.Rect(PAUSE_BUTTON_POS[0], PAUSE_BUTTON_POS[1], PAUSE_BUTTON_SIZE, PAUSE_BUTTON_SIZE)
                if pause_rect.collidepoint(mouse_pos):
                    paused = not paused
            elif paused:
                paused = False
            elif game_over:
                rematch_rect = pygame.Rect((WINDOW_SIZE[0]//2 - BUTTON_WIDTH//2, 
                                          WINDOW_SIZE[1]//2 + 50), 
                                         (BUTTON_WIDTH, BUTTON_HEIGHT))
                if rematch_rect.collidepoint(mouse_pos):
                    restart_game()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                paused = not paused

    # Show countdown screen
    if not game_started:
        screen.fill(WHITE)
        screen.blit(background, background_rect)
        
        if current_number < len(countdown_numbers):
            number = countdown_numbers[current_number]
            text = countdown_font.render(number, True, BLACK)
            text_rect = text.get_rect(center=(WINDOW_SIZE[0]//2, WINDOW_SIZE[1]//2))
            screen.blit(text, text_rect)
            
            if current_time - countdown_start >= countdown_duration:
                current_number += 1
                countdown_start = current_time
                
            pygame.display.flip()
            clock.tick(60)
            continue
        else:
            game_started = True
            start_time = pygame.time.get_ticks()

    # Check for game over conditions
    elapsed_time = (pygame.time.get_ticks() - start_time) // 1000
    time_left = max(0, GAME_DURATION - elapsed_time)
    
    if player1_health <= 0 or player2_health <= 0 or time_left <= 0:
        game_over = True
        screen.fill(BLACK)
        
        if player1_health <= 0:
            winner_text = "PLAYER 2 WINS!"
        elif player2_health <= 0:
            winner_text = "PLAYER 1 WINS!"
        elif time_left <= 0:
            if player1_health > player2_health:
                winner_text = "PLAYER 1 WINS!"
            elif player2_health > player1_health:
                winner_text = "PLAYER 2 WINS!"
            else:
                winner_text = "IT'S A TIE!!"

        text = victory_font.render(winner_text, True, WHITE)
        text_rect = text.get_rect(center=(WINDOW_SIZE[0]//2, WINDOW_SIZE[1]//2 - 50))
        screen.blit(text, text_rect)

        rematch_rect = draw_button("REMATCH", 
                                 (WINDOW_SIZE[0]//2 - BUTTON_WIDTH//2, 
                                  WINDOW_SIZE[1]//2 + 50))

        pygame.display.flip()
        clock.tick(60)
        continue

    if paused:
        # Create a copy of the current screen
        overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 128))  # RGBA — black with 50% transparency
        screen.blit(overlay, (0, 0))
        
        pause_text = pause_font.render("GAME PAUSED", True, WHITE)
        pause_rect = pause_text.get_rect(center=(WINDOW_SIZE[0]//2, WINDOW_SIZE[1]//2))
        screen.blit(pause_text, pause_rect)
        
        resume_text = font.render("Press Esc to Continue", True, WHITE)
        resume_rect = resume_text.get_rect(center=(WINDOW_SIZE[0]//2, WINDOW_SIZE[1]-50))
        screen.blit(resume_text, resume_rect)
        
        pygame.display.flip()
        clock.tick(60)
        continue

    keys = pygame.key.get_pressed()
    
    if keys[pygame.K_a]:
        player1_vel[0] = -PLAYER_SPEED
    elif keys[pygame.K_d]:
        player1_vel[0] = PLAYER_SPEED
    else:
        player1_vel[0] = 0
        
    if keys[pygame.K_LEFT]:
        player2_vel[0] = -PLAYER_SPEED
    elif keys[pygame.K_RIGHT]:
        player2_vel[0] = PLAYER_SPEED
    else:
        player2_vel[0] = 0

    # Apply different gravity based on position relative to main platform
    if player1_pos[1] > platforms[0].bottom:
        player1_vel[1] += REDUCED_GRAVITY
    else:
        player1_vel[1] += GRAVITY
        
    if player2_pos[1] > platforms[0].bottom:
        player2_vel[1] += REDUCED_GRAVITY
    else:
        player2_vel[1] += GRAVITY

    old_pos1 = player1_pos.copy()
    old_pos2 = player2_pos.copy()

    player1_pos[0] += player1_vel[0]
    player1_pos[1] += player1_vel[1]
    player2_pos[0] += player2_vel[0]
    player2_pos[1] += player2_vel[1]

    if player1_pos[1] > VOID_Y:
        player1_pos = INITIAL_POS1.copy()
        player1_vel = [0, 0]
        player1_health = max(0, player1_health - VOID_DAMAGE)
        player1_respawn_timer = RESPAWN_FLASH_DURATION
        
    if player2_pos[1] > VOID_Y:
        player2_pos = INITIAL_POS2.copy()
        player2_vel = [0, 0]
        player2_health = max(0, player2_health - VOID_DAMAGE)
        player2_respawn_timer = RESPAWN_FLASH_DURATION

    player1_pos[0] = max(0, min(player1_pos[0], WINDOW_SIZE[0] - PLAYER_SIZE))
    player2_pos[0] = max(0, min(player2_pos[0], WINDOW_SIZE[0] - PLAYER_SIZE))

    player1_rect = pygame.Rect(player1_pos[0], player1_pos[1], PLAYER_SIZE, PLAYER_SIZE)
    player2_rect = pygame.Rect(player2_pos[0], player2_pos[1], PLAYER_SIZE, PLAYER_SIZE)
    
    player1_on_ground = False
    player2_on_ground = False
    
    for platform in platforms:
        if player1_rect.colliderect(platform):
            if platform == platforms[0] or (player1_vel[1] > 0 and old_pos1[1] + PLAYER_SIZE <= platform.top + 10):
                if player1_vel[1] > 0 and old_pos1[1] + PLAYER_SIZE <= platform.top + 10:
                    if platform != platforms[0] and keys[pygame.K_s]:
                        continue
                    player1_pos[1] = platform.top - PLAYER_SIZE
                    player1_vel[1] = 0
                    player1_on_ground = True
                elif platform == platforms[0]:
                    if player1_vel[1] < 0 and old_pos1[1] >= platform.bottom - 10:
                        player1_pos[1] = platform.bottom
                        player1_vel[1] = 0
                    elif player1_vel[0] > 0 and old_pos1[0] + PLAYER_SIZE <= platform.left + 10:
                        player1_pos[0] = platform.left - PLAYER_SIZE
                        player1_vel[0] = 0
                    elif player1_vel[0] < 0 and old_pos1[0] >= platform.right - 10:
                        player1_pos[0] = platform.right
                        player1_vel[0] = 0

        if player2_rect.colliderect(platform):
            if platform == platforms[0] or (player2_vel[1] > 0 and old_pos2[1] + PLAYER_SIZE <= platform.top + 10):
                if player2_vel[1] > 0 and old_pos2[1] + PLAYER_SIZE <= platform.top + 10:
                    if platform != platforms[0] and keys[pygame.K_DOWN]:
                        continue
                    player2_pos[1] = platform.top - PLAYER_SIZE
                    player2_vel[1] = 0
                    player2_on_ground = True

                elif platform == platforms[0]:
                    if player2_vel[1] < 0 and old_pos2[1] >= platform.bottom - 10:  
                        player2_pos[1] = platform.bottom
                        player2_vel[1] = 0
                    elif player2_vel[0] > 0 and old_pos2[0] + PLAYER_SIZE <= platform.left + 10:  
                        player2_pos[0] = platform.left - PLAYER_SIZE
                        player2_vel[0] = 0
                    elif player2_vel[0] < 0 and old_pos2[0] >= platform.right - 10: 
                        player2_pos[0] = platform.right
                        player2_vel[0] = 0

    if player1_rect.colliderect(player2_rect):
        # Handle vertical stacking
        if player1_vel[1] > 0 and old_pos1[1] + PLAYER_SIZE <= old_pos2[1] + 10:
            player1_pos[1] = player2_pos[1] - PLAYER_SIZE
            player1_vel[1] = 0
            player1_on_ground = True
        elif player2_vel[1] > 0 and old_pos2[1] + PLAYER_SIZE <= old_pos1[1] + 10:
            player2_pos[1] = player1_pos[1] - PLAYER_SIZE
            player2_vel[1] = 0
            player2_on_ground = True

    if keys[pygame.K_w] and player1_on_ground:
        player1_vel[1] = JUMP_SPEED
    if keys[pygame.K_UP] and player2_on_ground:
        player2_vel[1] = JUMP_SPEED

    screen.fill(WHITE)
    
    screen.blit(background, background_rect)
    
    for platform in platforms:
        pygame.draw.rect(screen, BLACK, platform)
    
    # Draw player indicators when off screen
    if player1_pos[1] < 0:
        pygame.draw.polygon(screen, BLUE, [(player1_pos[0] + PLAYER_SIZE//2, 10), 
                                         (player1_pos[0] + PLAYER_SIZE//2 - 10, 30),
                                         (player1_pos[0] + PLAYER_SIZE//2 + 10, 30)])
    elif player1_pos[1] > WINDOW_SIZE[1] - PLAYER_SIZE:
        pygame.draw.polygon(screen, BLUE, [(player1_pos[0] + PLAYER_SIZE//2, WINDOW_SIZE[1] - 10),
                                         (player1_pos[0] + PLAYER_SIZE//2 - 10, WINDOW_SIZE[1] - 30),
                                         (player1_pos[0] + PLAYER_SIZE//2 + 10, WINDOW_SIZE[1] - 30)])

    if player2_pos[1] < 0:
        pygame.draw.polygon(screen, RED, [(player2_pos[0] + PLAYER_SIZE//2, 10),
                                        (player2_pos[0] + PLAYER_SIZE//2 - 10, 30),
                                        (player2_pos[0] + PLAYER_SIZE//2 + 10, 30)])
    elif player2_pos[1] > WINDOW_SIZE[1] - PLAYER_SIZE:
        pygame.draw.polygon(screen, RED, [(player2_pos[0] + PLAYER_SIZE//2, WINDOW_SIZE[1] - 10),
                                        (player2_pos[0] + PLAYER_SIZE//2 - 10, WINDOW_SIZE[1] - 30),
                                        (player2_pos[0] + PLAYER_SIZE//2 + 10, WINDOW_SIZE[1] - 30)])
    
    if player1_respawn_timer <= 0 or player1_respawn_timer % FLASH_INTERVAL > FLASH_INTERVAL//2:
        if 0 <= player1_pos[1] <= WINDOW_SIZE[1] - PLAYER_SIZE:
            player1_surface = pygame.Surface((PLAYER_SIZE, PLAYER_SIZE), pygame.SRCALPHA)
            pygame.draw.rect(player1_surface, (*BLUE, 128 if player1_respawn_timer > 0 else 255), (0, 0, PLAYER_SIZE, PLAYER_SIZE))
            screen.blit(player1_surface, (player1_pos[0], player1_pos[1]))
    
    if player2_respawn_timer <= 0 or player2_respawn_timer % FLASH_INTERVAL > FLASH_INTERVAL//2:
        if 0 <= player2_pos[1] <= WINDOW_SIZE[1] - PLAYER_SIZE:
            player2_surface = pygame.Surface((PLAYER_SIZE, PLAYER_SIZE), pygame.SRCALPHA)
            pygame.draw.rect(player2_surface, (*RED, 128 if player2_respawn_timer > 0 else 255), (0, 0, PLAYER_SIZE, PLAYER_SIZE))
            screen.blit(player2_surface, (player2_pos[0], player2_pos[1]))
    
    if player1_respawn_timer > 0:
        player1_respawn_timer -= 1
    if player2_respawn_timer > 0:
        player2_respawn_timer -= 1
    
    # Only draw labels when players are visible on screen
    if 0 <= player1_pos[1] <= WINDOW_SIZE[1] - PLAYER_SIZE:
        p1_label = font.render("P1", True, BLACK)
        screen.blit(p1_label, (player1_pos[0] + PLAYER_SIZE//4, player1_pos[1] - 25))
    
    if 0 <= player2_pos[1] <= WINDOW_SIZE[1] - PLAYER_SIZE:
        p2_label = font.render("P2", True, BLACK)
        screen.blit(p2_label, (player2_pos[0] + PLAYER_SIZE//4, player2_pos[1] - 25))
    
    # Draw health bars at the top
    pygame.draw.rect(screen, BLACK, (HEALTH_BAR_P1_POS[0], HEALTH_BAR_P1_POS[1], HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT), 2)
    pygame.draw.rect(screen, GREEN, (HEALTH_BAR_P1_POS[0], HEALTH_BAR_P1_POS[1], 
                    HEALTH_BAR_WIDTH * (player1_health/MAX_HEALTH), HEALTH_BAR_HEIGHT))
    p1_text = font.render("PLAYER 1", True, BLACK)
    screen.blit(p1_text, (HEALTH_BAR_P1_POS[0], HEALTH_BAR_P1_POS[1] + HEALTH_BAR_HEIGHT + 5))  # Changed position to below health bar
    
    pygame.draw.rect(screen, BLACK, (HEALTH_BAR_P2_POS[0], HEALTH_BAR_P2_POS[1], HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT), 2)
    pygame.draw.rect(screen, GREEN, (HEALTH_BAR_P2_POS[0], HEALTH_BAR_P2_POS[1], 
                    HEALTH_BAR_WIDTH * (player2_health/MAX_HEALTH), HEALTH_BAR_HEIGHT))
    p2_text = font.render("PLAYER2", True, BLACK)
    screen.blit(p2_text, (HEALTH_BAR_P2_POS[0], HEALTH_BAR_P2_POS[1] + HEALTH_BAR_HEIGHT + 5))  # Changed position to below health bar

    elapsed_time = (pygame.time.get_ticks() - start_time) // 1000
    time_left = max(0, GAME_DURATION - elapsed_time)
    timer_text = timer_font.render(str(time_left), True, BLACK)
    timer_rect = timer_text.get_rect(center=(WINDOW_SIZE[0]//2, 30))
    screen.blit(timer_text, timer_rect)

    # Draw pause button
    if game_started and not game_over:
        draw_pause_button()

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
